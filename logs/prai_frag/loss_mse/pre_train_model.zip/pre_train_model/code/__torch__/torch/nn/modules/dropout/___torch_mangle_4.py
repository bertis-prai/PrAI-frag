class Dropout(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  def forward(self: __torch__.torch.nn.modules.dropout.___torch_mangle_4.Dropout,
    argument_1: Tensor) -> Tensor:
    x_feat2 = torch.dropout(argument_1, 0.40000000000000002, False)
    return x_feat2
