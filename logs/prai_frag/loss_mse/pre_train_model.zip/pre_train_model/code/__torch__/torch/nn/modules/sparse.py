class Embedding(Module):
  __parameters__ = ["weight", ]
  __buffers__ = []
  weight : Tensor
  training : bool
  def forward(self: __torch__.torch.nn.modules.sparse.Embedding,
    input: Tensor) -> Tensor:
    input0 = torch.embedding(self.weight, input, -1, False, False)
    return input0
