class PeptideFragNet(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  embedding : __torch__.torch.nn.modules.sparse.Embedding
  gru1 : __torch__.torch.nn.modules.rnn.GRU
  gru1_dropout : __torch__.torch.nn.modules.dropout.Dropout
  gru_attention : __torch__.utils.models.Attention
  linear : __torch__.torch.nn.modules.linear.Linear
  linear2 : __torch__.torch.nn.modules.linear.___torch_mangle_0.Linear
  featlinear : __torch__.torch.nn.modules.linear.___torch_mangle_1.Linear
  feat2conv : __torch__.torch.nn.modules.container.Sequential
  feat2linear : __torch__.torch.nn.modules.linear.___torch_mangle_5.Linear
  multiply : __torch__.utils.models.Multiply
  linear_relu : __torch__.torch.nn.modules.activation.___torch_mangle_6.ReLU
  leaky_relu : __torch__.torch.nn.modules.activation.___torch_mangle_7.LeakyReLU
  dropout : __torch__.torch.nn.modules.dropout.___torch_mangle_8.Dropout
  gru2 : __torch__.torch.nn.modules.rnn.___torch_mangle_9.GRU
  gru2_dropout : __torch__.torch.nn.modules.dropout.___torch_mangle_10.Dropout
  gru_attention2 : __torch__.utils.models.___torch_mangle_11.Attention
  linear3 : __torch__.torch.nn.modules.linear.___torch_mangle_12.Linear
  prediction : __torch__.torch.nn.modules.linear.___torch_mangle_13.Linear
  def forward(self: __torch__.utils.models.PeptideFragNet,
    x: Tensor,
    x_feat: Tensor,
    x_feat2: Tensor) -> Tensor:
    _0 = self.prediction
    _1 = self.linear3
    _2 = self.gru_attention2
    _3 = self.gru2
    _4 = self.multiply
    _5 = self.feat2linear
    _6 = self.feat2conv
    _7 = self.featlinear
    _8 = self.linear2
    _9 = self.leaky_relu
    _10 = self.dropout
    _11 = self.gru_attention
    _12 = self.gru1_dropout
    _13 = self.gru1
    _14 = self.embedding
    x0 = torch.to(x, 4, False, False, None)
    input = torch.squeeze(x0)
    x_feat0 = torch.to(x_feat, 6, False, False, None)
    input0 = torch.unsqueeze(x_feat0, 0)
    x_feat20 = torch.to(x_feat2, 6, False, False, None)
    input1 = torch.unsqueeze(x_feat20, 1)
    _15 = (_13).forward((_14).forward(input, ), )
    _16, _17, = _15
    _18 = (_11).forward((_12).forward(_16, ), )
    _19 = (_9).forward((_10).forward(_18, ), )
    _20 = (_8).forward(_19, )
    x_feat1 = torch.transpose((_7).forward(input0, ), 0, 1)
    x_feat3 = torch.squeeze(x_feat1, 1)
    x_feat24 = torch.squeeze((_6).forward(input1, ))
    input2 = torch.unsqueeze(x_feat24, 0)
    x_feat25 = torch.squeeze((_5).forward(input2, ))
    t = torch.cat([x_feat3, x_feat25], 1)
    repeat_vector_input = torch.unsqueeze((_4).forward(_20, t, ), 1)
    input3 = torch.repeat(repeat_vector_input, [1, 15, 2])
    _21 = (_2).forward((_3).forward(input3, _17, ), )
    _22 = (_9).forward1((_10).forward1(_21, ), )
    input4 = torch.squeeze(_22, 1)
    _23 = (_0).forward((_1).forward(input4, ), )
    return _23
class Attention(Module):
  __parameters__ = ["weight", "b", ]
  __buffers__ = []
  weight : Tensor
  b : Tensor
  training : bool
  def forward(self: __torch__.utils.models.Attention,
    argument_1: Tensor) -> Tensor:
    _24 = self.b
    _25 = self.weight
    x = torch.contiguous(argument_1, memory_format=0)
    _26 = torch.mm(torch.view(x, [-1, 256]), _25)
    eij = torch.view(_26, [-1, 15])
    eij0 = torch.add(eij, _24, alpha=1)
    eij1 = torch.tanh(eij0)
    a = torch.exp(eij1)
    _27 = torch.div(a, torch.sum(a, [1], True, dtype=None))
    a0 = torch.add(_27, CONSTANTS.c0, alpha=1)
    weighted_input = torch.mul(x, torch.unsqueeze(a0, -1))
    input = torch.sum(weighted_input, [1], False, dtype=None)
    return input
class Multiply(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  def forward(self: __torch__.utils.models.Multiply,
    argument_1: Tensor,
    t: Tensor) -> Tensor:
    _28 = ops.prim.NumToTensor(torch.size(argument_1, 0))
    _29 = int(_28)
    _30 = ops.prim.NumToTensor(torch.size(argument_1, 1))
    result = torch.ones([_29, int(_30)], dtype=6, layout=None, device=torch.device("cpu"), pin_memory=False)
    result0 = torch.to(result, dtype=6, layout=0, device=torch.device("cuda"), pin_memory=None, non_blocking=False, copy=False, memory_format=None)
    result1 = torch.mul_(result0, argument_1)
    return torch.mul_(result1, t)
