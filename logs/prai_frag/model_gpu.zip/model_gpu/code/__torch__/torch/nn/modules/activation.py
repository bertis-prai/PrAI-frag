class ReLU(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  def forward(self: __torch__.torch.nn.modules.activation.ReLU,
    argument_1: Tensor) -> Tensor:
    return torch.relu(argument_1)
class LeakyReLU(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  def forward(self: __torch__.torch.nn.modules.activation.LeakyReLU,
    argument_1: Tensor) -> Tensor:
    input = torch.leaky_relu(argument_1, 0.29999999999999999)
    return input
