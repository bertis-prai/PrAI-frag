class Attention(Module):
  __parameters__ = ["weight", "b", ]
  __buffers__ = []
  weight : Tensor
  b : Tensor
  training : bool
  def forward(self: __torch__.utils.models.___torch_mangle_11.Attention,
    argument_1: Tensor) -> Tensor:
    _0 = self.b
    _1 = self.weight
    _2 = torch.contiguous(argument_1, memory_format=0)
    _3 = torch.mm(torch.view(_2, [-1, 256]), _1)
    eij = torch.view(_3, [-1, 15])
    eij0 = torch.add(eij, _0, alpha=1)
    eij1 = torch.tanh(eij0)
    a = torch.exp(eij1)
    _4 = torch.div(a, torch.sum(a, [1], True, dtype=None))
    a0 = torch.add(_4, CONSTANTS.c0, alpha=1)
    weighted_input = torch.mul(argument_1, torch.unsqueeze(a0, -1))
    input = torch.sum(weighted_input, [1], False, dtype=None)
    return input
