class LeakyReLU(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  def forward(self: __torch__.torch.nn.modules.activation.___torch_mangle_6.LeakyReLU,
    argument_1: Tensor) -> Tensor:
    input = torch.leaky_relu(argument_1, 0.29999999999999999)
    return input
  def forward1(self: __torch__.torch.nn.modules.activation.___torch_mangle_6.LeakyReLU,
    argument_1: Tensor) -> Tensor:
    feature_extracted = torch.leaky_relu(argument_1, 0.29999999999999999)
    return feature_extracted
