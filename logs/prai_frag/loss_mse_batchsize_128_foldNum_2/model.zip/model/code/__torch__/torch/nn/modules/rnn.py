class GRU(Module):
  __parameters__ = ["weight_ih_l0", "weight_hh_l0", "bias_ih_l0", "bias_hh_l0", "weight_ih_l0_reverse", "weight_hh_l0_reverse", "bias_ih_l0_reverse", "bias_hh_l0_reverse", ]
  __buffers__ = []
  weight_ih_l0 : Tensor
  weight_hh_l0 : Tensor
  bias_ih_l0 : Tensor
  bias_hh_l0 : Tensor
  weight_ih_l0_reverse : Tensor
  weight_hh_l0_reverse : Tensor
  bias_ih_l0_reverse : Tensor
  bias_hh_l0_reverse : Tensor
  training : bool
  def forward(self: __torch__.torch.nn.modules.rnn.GRU,
    argument_1: Tensor) -> Tuple[Tensor, Tensor]:
    _0 = self.bias_hh_l0_reverse
    _1 = self.bias_ih_l0_reverse
    _2 = self.weight_hh_l0_reverse
    _3 = self.weight_ih_l0_reverse
    _4 = self.bias_hh_l0
    _5 = self.bias_ih_l0
    _6 = self.weight_hh_l0
    _7 = self.weight_ih_l0
    max_batch_size = ops.prim.NumToTensor(torch.size(argument_1, 0))
    hx = torch.zeros([2, int(max_batch_size), 128], dtype=6, layout=None, device=torch.device("cpu"), pin_memory=False)
    input, hx0 = torch.gru(argument_1, hx, [_7, _6, _5, _4, _3, _2, _1, _0], True, 1, 0., False, True, True)
    return (input, hx0)
